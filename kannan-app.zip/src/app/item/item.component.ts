import { Item } from '../item.model';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  metricsTest: string;
  metricsMaintanability: string;
  metricsSecurity: string;
  metricsWorkmanship: string;
  
  test: number = 12;

  metricsUp: string = "fa fa-arrow-up fa-5x color-green";
  metricsDown: string = "fa fa-arrow-down fa-5x color-red";
  // metricsLeft: string = "fa fa-arrow-left fa-5x color-yellow";
  metricsRight: string = "fa fa-arrow-right fa-5x color-yellow";

  @Input()
  item: Item;

  constructor() {}

  ngOnInit() {
    if (this.item.metrics.test[1]) {
      this.metricsTest = this.metricsUp;
    } else {
       this.metricsTest = this.metricsDown;
    }

     if (this.item.metrics.maintain[1]) {
      this.metricsMaintanability = this.metricsUp;
    } else {
       this.metricsMaintanability = this.metricsDown;
     }
    
     this.metricsSecurity = this.metricsRight;
     this.metricsWorkmanship = this.metricsRight;
  }

  getContentCss(itemState: string) {
    let contentCss = "row tab-pane ";
    switch (itemState) {
      case "Pending":
        contentCss += " ui-accordion-content-pending";
        break; 
        case "Running":
        contentCss += " ui-accordion-content-running";
        break; 
        case "Rejected":
        contentCss += " ui-accordion-content-rejected";
        break; 
        case "Complete":
        contentCss += " ui-accordion-content-complete";
        break; 
        case "Accepted":
        contentCss += " ui-accordion-content-accepted";
        break; 
        
    }
    return contentCss;
  }
}
