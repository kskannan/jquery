
export class Item {
    constructor(
        public itemId:string,
        public owner:string,
        public timeStarted:any,
        public state: String,
        public metrics:any
    ){}
}
