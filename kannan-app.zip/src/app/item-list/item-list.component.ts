import { Item } from '../item.model';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {



  @Input()
  items: Array<Item>;

    
  panelHeader: string;
  panelBody: string;


  constructor() { }

  ngOnInit() {
  }

  getCss(itemState: string, cssName:string) {
    let css = cssName;
    switch (itemState) {
      case "Pending":
        css += "pending";
        break; 
        case "Running":
         css += "running";
        break; 
        case "Rejected":
         css += "rejected";
        break; 
        case "Complete":
         css += "complete";
        break; 
        case "Accepted":
          css += "accepted";
        break; 
    }
      return css;
  }  

}
