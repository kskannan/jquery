import { Item } from './item.model';
import { Component } from '@angular/core';
import { ItemService } from './item.service';

import "bootstrap/dist/css/bootstrap.css";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app';

  appCss: any;

  constructor(private itemService: ItemService) { 
  }

  items: Array<Item> = [];

  ngOnInit() {
    this.itemService.loadItems()
      .subscribe(resp => this.items = resp.items);
  }
}
